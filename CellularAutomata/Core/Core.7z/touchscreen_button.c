/*
 * button.c
 *
 *  Created on: Sep 29, 2024
 *      Author: Max
 */

#include "ili9341.h"
#include "touchscreen_button.h"
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

Button * Button_Create(uint16_t x, uint16_t y, uint16_t width, uint16_t height,
	                 uint16_t font_width, uint16_t font_height)
{
	Button * button = (Button*) malloc(sizeof(Button));

	if (button == NULL)
	{
		return NULL;
	}

	button->x = x;
	button->y = y;
	button->width = width;
	button->height = height;
	button->font_width = font_width;
	button->font_height = font_height;

	button->num_states = 0;
	button->state_i = 0;

	return button;
}

void Button_AddState(Button * button, uint16_t color_text, uint16_t color_bg, char text[])
{
	if (button == NULL)
	{
		return;
	}

	if (button->state_table == NULL)
	{
		button->state_table = (ButtonState*) malloc(sizeof(ButtonState));
		button->num_states = 1;
	}
	else
	{
		++button->num_states;
		button->state_table = (ButtonState*) realloc(button->state_table,
													 sizeof(ButtonState) * button->num_states);
		ButtonState new_state = {.color_text = color_text,
								 .color_bg = color_bg};
		strcpy(new_state.text, text);
		button->state_table[button->num_states - 1] = new_state;
	}

	if (button->state_table == NULL)
	{
		return;
	}
}

void Button_Draw(Button * button)
{
	if (button == NULL)
	{
		return;
	}

	ButtonState * state = button->state_table + button->state_i;

	lcdFillRect(button->x, button->y, button->width, button->height, state->color_bg);
	lcdDrawRect(button->x, button->y, button->width, button->height, state->color_text);
	lcdDrawLine(button->x + button->width + 1, button->y,
				button->x + button->width + 1, button->y + button->height,
				state->color_text);
	lcdDrawLine(button->x,                 button->y + button->height + 1,
			    button->x + button->width, button->y + button->height + 1,
				state->color_text);

	uint16_t text_length_x = button->font_width * strlen(state->text);
	uint16_t text_length_y = button->font_height;

	uint16_t center_x = button->x + button->width / 2;
	uint16_t center_y = button->y + button->height / 2;

	lcdSetCursor(center_x - text_length_x / 2, center_y - text_length_y / 2);
	lcdSetTextColor(state->color_text, state->color_bg);
	lcdPrintf(state->text);
}

bool Button_IsPressed(Button * button, uint16_t x, uint16_t y)
{
	if (button == NULL)
	{
		false;
	}

	return button->x < x && x < button->x + button->width
	    && button->y < y && y < button->y + button->height;
}

void Button_Toggle(Button * button)
{
	if (button == NULL)
	{
		return;
	}

	button->state_i = (button->state_i + 1) % button->num_states;
}

void Button_SetState(Button * button, uint8_t state_i)
{
	if (button == NULL)
	{
		return;
	}

	button->state_i = state_i;
}
