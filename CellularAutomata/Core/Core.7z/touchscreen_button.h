/*
 * XPT2046_button.h
 *
 *  Created on: Sep 29, 2024
 *      Author: Max
 */

#ifndef INC_TOUCHSCREEN_BUTTON_H_
#define INC_TOUCHSCREEN_BUTTON_H_

#include <stdbool.h>

typedef struct ButtonState_ {
	uint16_t color_text;
	uint16_t color_bg;
	char text[8];
} ButtonState;

typedef struct Button_ {
	uint8_t num_states;
	uint8_t state_i;
	ButtonState* state_table;

	uint16_t x;
	uint16_t y;
	uint16_t width;
	uint16_t height;

	uint16_t font_width;
	uint16_t font_height;
} Button;

Button* Button_Create(uint16_t x, uint16_t y, uint16_t width, uint16_t height,
	                 uint16_t font_width, uint16_t font_height);

void Button_AddState(Button * button, uint16_t color_text, uint16_t color_bg, char text[]);

void Button_Draw(Button * button);

bool Button_IsPressed(Button * button, uint16_t x, uint16_t y);

void Button_Toggle(Button * button);

void Button_SetState(Button * button, uint8_t state_i);

#endif /* INC_TOUCHSCREEN_BUTTON_H_ */
